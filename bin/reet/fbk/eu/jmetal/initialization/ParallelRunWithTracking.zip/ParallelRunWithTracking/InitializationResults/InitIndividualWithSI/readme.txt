This is the initial individuals of 10 different runs with 10 different seeds.

Problem: EnergyPLANProblemAalborg2ObjectivesWith1EnergyPLANEvolution (modified to work without PP and boiler capacity, now, the number of decision variable is 5. The file will be found in initilization folder)

seed [] = {545454, 565656, 455885, 245454, 714451,752453,125742,455411, 447551, 844545 };

Boolean favorGenesforRE[] ={true, true, true, true, true};
Boolean favorGenesforConventionalPP[] ={false, false, false, false, false};

Parameters regarding smal initialization:
theta = 6.0
MaxDistributionIndex = 3
numberOfIndevPerCombination = 4
numberOfRandomIndividuals=200