This folder contains the folder thatis used to run initilization with tracking for all the algorithm (NSGAII, NSGAII_SI, SPEA2, SPEA2_SI).

How do to:
1. Copy EnergyPLAN_SEP_2013 folder from "C:\Users\mahbub\Documents\GitHub\EnergyPLANDomainKnowledgeEAStep1"
2. create 4 folders with the same contain of this folder in deskop (named: NSGAIIWithTracking, NSGAIISIWithTracking, ..), path: "C:\Users\mahbub\Desktop\NSGAIISIWithTracking"
3. run coresponding bat file 
4. collete results from "C:\Users\mahbub\Desktop\NSGAIISIWithTracking\InitializationResults\WithTrack"